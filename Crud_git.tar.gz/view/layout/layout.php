<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Teste para vaga de Estágio Desenvolvedor Web PHP</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>css/bootstrap.min.css">
</head>
<body>
<header>
	<ul class="nav nav-pills"">
	  <li><a href="<?php echo $base_url;?>usuario">Listagem geral</a></li>
	  <li><a href="<?php echo $base_url;?>usuario/create.php">Criar usuários</a></li>
	</ul>
</header>
<section>
	
<?php print $content;?>
</section>
<script src="<?php echo $base_url; ?>js/bootstrap.min.js"></script>
</body>
</html>
