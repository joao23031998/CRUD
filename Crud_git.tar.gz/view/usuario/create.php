<h1>Cadastrar usuário</h1>
<form method="post">
	  <div class="form-group">
	    <label for="nomeCadastro">Nome</label>
	    <input name='nome' type="text" class="form-control" id="nomeCadastro" placeholder="Nome">
	  </div>
	  <div class="form-group">
	    <label for="emailCadastro">Email</label>
	    <input name='email' type="email" class="form-control" id="emailCadastro" placeholder="Email">
	  </div>
	  <div class="form-group">
	    <label for="senhaCadastro">Senha</label>
	    <input name='senha' type="password" class="form-control" id="senhaCadastro" placeholder="Senha">
	  </div>
	  <div class="form-group">
	    <label for="dataNascimentoCadastro">Data de nascimento</label>
	    <input name='dataNascimento' type="date" class="form-control" id="dataNascimentoCadastro" placeholder="Data de nascimento">
	  </div>
	  <button type="submit" class="btn btn-default">Cadastrar</button>
</form>
