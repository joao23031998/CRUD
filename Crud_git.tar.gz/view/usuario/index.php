<h1>Listagem geral</h1>
<table class="table table-striped">
	<thead>
		<td><b>Nome</b></td>
		<td><b>Email</b></td>
		<td><b>Data de nascimento</b></td>
	</thead>
	<?php foreach($view['usuarios'] as $usuario): ?>

	<tr>
		<td>
			<a href="show.php?id='<?php echo $usuario->getId(); ?>'">
				<?php echo $usuario->getNome() ?>
			</a>
		</td>

		<td><?php echo $usuario->getEmail() ?></td>
		<td><?php echo date("d/m/Y", strtotime($usuario->getDataNascimento())) ?></td>
		
		<td>
			<a href="update.php?id=<?php echo $usuario->getId(); ?>">
				<button type="submit" class="btn btn-primary">alterar</button>
			</a>
		</td>

		<td>
			<a href="delete.php?id=<?php echo $usuario->getId(); ?>">
				<button type="submit" class="btn btn-danger">excluir</button>
			</a>
		</td>
	</tr>

	<?php endforeach; ?>
</table>

<nav aria-label="Page navigation">
  <ul class="pagination">
    <li>
      <a href="#" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li><a href="#">1</a></li>
    <li><a href="#">2</a></li>
    <li><a href="#">3</a></li>
    <li><a href="#">4</a></li>
    <li><a href="#">5</a></li>
    <li>
      <a href="#" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>