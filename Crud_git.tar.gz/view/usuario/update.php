<h1>Alterar usuário</h1>
<form method="post" action="../usuario/update.php">
	  <div class="form-group">
	    <label for="nomeCadastro">Nome</label>
	    <input name='nome' type="text" class="form-control" id="nomeCadastro" placeholder="Nome" value="<?php echo $view['usuario']->getNome(); ?>">
	  </div>
	  <div class="form-group">
	    <label for="emailCadastro">Email</label>
	    <input name='email' type="email" class="form-control" id="emailCadastro" placeholder="Email" value="<?php echo $view['usuario']->getEmail(); ?>">
	  </div>
	  <div class="form-group">
	    <label for="senhaCadastro">Senha</label>
	    <input name='senha' type="password" class="form-control" id="senhaCadastro" placeholder="Digite um nova senha">
	  </div>
	  <div class="form-group">
	    <label for="dataNascimentoCadastro">Data de nascimento</label>
	    <input name='dataNascimento' type="date" class="form-control" id="dataNascimentoCadastro" placeholder="Data de nascimento" value="<?php echo $view['usuario']->getDataNascimento(); ?>">
	  </div>
	  <input type="hidden" value="<?php echo $view['usuario']->getId(); ?>" name="id">
	  <button type="submit" class="btn btn-default">Alterar</button>
</form>

