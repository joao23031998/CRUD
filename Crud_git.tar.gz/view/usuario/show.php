<h1>Usuário</h1>
<table class="table table-striped">
	<thead>
		<td><b>Nome</b></td>
		<td><b>Email</b></td>
		<td><b>Data de nascimento</b></td>
	</thead>	
	<tr>
		<td><?php echo $view['usuario']->getNome(); ?></td>
		<td><?php echo $view['usuario']->getEmail(); ?></td>
		<td><?php echo date("d/m/Y", strtotime($view['usuario']->getDataNascimento())) ?></td>
		
	</tr>	
</table>

