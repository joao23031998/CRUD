<?php

namespace App;

class View{

	static public function render($viewName, $view = []){

		ob_start();

		require_once __DIR__ . "/../view/{$viewName}.php";
		
		$content = ob_get_clean();

		$base_url = "http://{$_SERVER['SERVER_NAME']}/Crud_git/";

		require_once __DIR__ . "/../view/layout/layout.php";
	}
}
