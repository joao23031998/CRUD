<?php

namespace App;

class Conexao {
	private $servername = "127.0.0.1";
	private $username = "root";
	private $password = "root";
	private $dbname = "CRUDBD";
	private $conn;

	public function __construct(){
		$this->conn = new \mysqli($this->servername, $this->username, $this->password, $this->dbname);

		if ($this->conn->connect_error) {
		    die("Algo errado na conexão com o banco: " . $this->conn->connect_error);
		}
	}

	public function getConexao(){
		return $this->conn;
	}
}

