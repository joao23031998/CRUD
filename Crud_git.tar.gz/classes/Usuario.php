<?php
	
namespace App;

class Usuario{

	private $nome;
	private $email;
	private $senha;
	private $dataNascimento;
	private $id;

	public function __construct($nome, $email, $senha, $dataNascimento){
		$this->nome = $nome;
		$this->email = $email;
		$this->senha = $senha;
		$this->dataNascimento = $dataNascimento;
	}

	public function setId($id){
		$this->id = $id;
		return $this;
	}

	public function getId(){
		return $this->id;
	}

	public function setNome($nome){
		$this->nome = $nome;
		return $this;
	}

	public function getNome(){
		return $this->nome;
	}

	public function getEmail(){
		return $this->email;
	}

	public function setSenha($senha){
		$this->senha = md5($senha);
		return $this;
	}

	public function getSenha(){
		return $this->senha;
	}

	public function getDataNascimento(){
		return $this->dataNascimento;
	}

	public function insere(){
		$conn = new Conexao();
		
		$query = "INSERT INTO usuario (nome, email, senha, data_de_nascimento) 
		VALUES ('{$this->getNome()}', '{$this->getEmail()}', md5('{$this->getSenha()}'), '{$this->getDataNascimento()}')";

		if ($result = $conn->getConexao()->query($query)) {
			$this->setId($conn->getConexao()->insert_id);
		} else {
			echo "Error: " . $query . "<br>" . $conn->getConexao()->error;
		}
	}

	static public function get($id){

		$conn = new Conexao();
		
		$query = "SELECT * FROM usuario WHERE id = {$id}";

        $result = $conn->getConexao()->query($query);

		$usuario_array = mysqli_fetch_array($result);
		
		if (is_null($usuario_array)) {
			return null;
		}
		
        $usuario = new Usuario($usuario_array['nome'], 
							   $usuario_array['email'], 
							   $usuario_array['senha'], 
							   $usuario_array['data_de_nascimento']
							   );
        $usuario->setId($id);

        return $usuario;

	}

	static public function getList(){
		$usuarios = [];

		$conn = new Conexao();
		
		$query = "SELECT * FROM usuario ORDER BY id DESC";

        $result = $conn->getConexao()->query($query);

		while($usuario_array = mysqli_fetch_assoc($result)) {

			$usuario = new Usuario($usuario_array['nome'], 
							   $usuario_array['email'], 
							   $usuario_array['senha'], 
							   $usuario_array['data_de_nascimento']
							   );

			$usuario->setId($usuario_array['id']);

			array_push($usuarios, $usuario);
		}
		
        return $usuarios;
	}
	 	
	public function update($id){

		$conn = new Conexao();
		
		$query = "UPDATE usuario SET nome='{$this->getNome()}',
									 email='{$this->getEmail()}', 
									 senha= md5('{$this->getSenha()}'),
									 data_de_nascimento='{$this->getDataNascimento()}'
								 WHERE id ='{$id}';";

        return $conn->getConexao()->query($query);
	}

	static public function delete($id) {

		$conn = new Conexao();

		$query = "DELETE FROM usuario WHERE id = $id";

        return $conn->getConexao()->query($query);
		
	}

}

