<?php
	
require_once __DIR__ . "/../bootstrap.php";

if(isset($_GET['id']) && !is_null($_GET['id'])){
	
	$usuario = \App\Usuario::delete($_GET['id']);

	if ($usuario == null) {
		\App\View::render('layout/404');
		die();
	}

	\App\View::render('usuario/delete', ['usuario'=>$usuario]);
}

?>