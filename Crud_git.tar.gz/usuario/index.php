<?php
	
	require_once __DIR__ . "/../bootstrap.php";
	
	$usuarios = \App\Usuario::getList();

	\App\View::render('usuario/index', ['usuarios'=>$usuarios]);

