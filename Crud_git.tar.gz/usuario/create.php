<?php

require_once __DIR__ . "/../bootstrap.php";

if ($_POST) {
	
	if (empty($_POST['nome'])){
		echo "Preencha os campos obrigatórios!";
		die();
	}

	if (empty($_POST['senha'])) {
		echo "Preencha os campos obrigatórios!";
		die();
	}
}
	
if ($_POST) {
	$usuario = new \App\Usuario($_POST['nome'], 
						   $_POST['email'], 
						   $_POST['senha'], 
						   $_POST['dataNascimento'] 
						   );
	$usuario->insere();
	header('Location: show.php?id='. $usuario->getId());
	exit();

}else{

	\App\View::render('usuario/create');

}

