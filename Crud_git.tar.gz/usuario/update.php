<?php

require_once __DIR__ . "/../bootstrap.php";

if(isset($_GET['id']) && !is_null($_GET['id'])){
	
	$usuario = \App\Usuario::get($_GET['id']);
	$usuario->setId($_GET['id']);

	if ($usuario == null) {
		\App\View::render('layout/404');
		die();
	}

	\App\View::render('usuario/update', ['usuario'=>$usuario]);
}

if(isset($_POST)){

	
	$usuario2 = new \App\Usuario(@$_POST['nome'], 
						   @$_POST['email'], 
						   @$_POST['senha'], 
						   @$_POST['dataNascimento'] 
						   );
	
	if ($_POST) {
		if (empty($_POST['nome'])){
			echo "Preencha os campos obrigatórios!";
			header('Location: update.php?fracasso=true');
		}

		if (empty($_POST['senha'])) {
			echo "Preencha os campos obrigatórios!";
			die();
		}
		
		if ($usuario2->update($_POST['id'])) {
			echo "Alteração realizada com sucesso!";

		}else{
			echo "Não foi possivel fazer a alteração!";

		}
	}


}
